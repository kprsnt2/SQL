select * from employee
create table deptartment (d_id int, d_name varchar(20), d_location varchar(20));
insert into deptartment values
	(1, 'Sales', 'Delhi'),
	(2, 'Operations', 'Hyderabad'),
	(3, 'Support', 'Bangalore'),
	(4, 'Tech', 'Hyderabad'),
	(5, 'Analytics', 'Chennai');
select * from employee
select * from dept